
import java.util.Scanner;


public class attendance {
	
	public static void main (String[] args) {
		Teacher t=new Teacher();
		Student s=new Student();
		System.out.println("Select from options");
		System.out.println("1.Teacher");
		System.out.println("2.Student");
		System.out.println("3.exit");

		
		int choice;
		Scanner sc=new Scanner(System.in);
		while(true) {
			System.out.println("Enter choice");
				choice=sc.nextInt();
			switch(choice)
			{
			case 1: t.Teacher1();
				    break;
			case 2:s.Student1();
				    break;
			case 3:break;
			default:System.out.println("Wrong choice");	    
		
		}
			if(choice==3)
			break;
			}
			
		sc.close();
	}

}