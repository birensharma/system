import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Teacher {
	Scanner s=new Scanner(System.in);
	public void Teacher1() {
		String FILENAME = "Attendance.txt";
		BufferedWriter bw = null;
		FileWriter fw = null;
		try {

			

			fw = new FileWriter(FILENAME);
			bw = new BufferedWriter(fw);
			System.out.println("Enter the number of student");
			int j =s.nextInt();
			System.out.println("Enter name and attendance");
			for(int i=0;i<=j;i++)
			{
				String name=s.nextLine();
				bw.write(name);
				bw.write(" ");
				bw.write("\n");
			}
			

			System.out.println("Done");

		} catch (IOException e) {

			e.printStackTrace();

		} finally {

			try {

				if (bw != null)
					bw.close();

				if (fw != null)
					fw.close();

			} catch (IOException ex) {

				ex.printStackTrace();

			}
			
		}
    }
}