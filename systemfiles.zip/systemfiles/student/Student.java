import java.io.FileReader;
import java.io.IOException;

public class Student {
	public void Student1()
	{
		String FILENAME1 = "Attendance.txt";
		System.out.println("Here's today's attendance");
		try {
            FileReader reader = new FileReader(FILENAME1);
            int character;
 
            while ((character = reader.read()) != -1) {
                System.out.print((char) character);
            }
            reader.close();
 
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	}
 
