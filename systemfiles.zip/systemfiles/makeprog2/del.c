#include <stdio.h>
#include <stdlib.h>
void del(int A[], int n)
{
	int t, i, j;
	printf("\n Enter number to delete:");
	scanf("%d", &t);
	for (i = 0; i < n; i++)
	{
		if (t == A[i])
		{
			for (j = i; j < n; j++)
			{
				A[j]=A[j+1];
			}
			break;
		}
	}
	printf("\n List after deletion:\n");
	for (i=0; i<n-1; i++)
		printf("%d\t", A[i]);
printf("\n");
}
