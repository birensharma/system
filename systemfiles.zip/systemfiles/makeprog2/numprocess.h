extern void binary();
extern void bub_sort();
extern void del();
extern void ins();
