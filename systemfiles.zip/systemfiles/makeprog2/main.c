#include<stdio.h>
#include<stdlib.h>
#include"numprocess.h"

int main()
{
	int n,i,j,choice;
	printf("Enter no of elements ");
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	while(1)
	{
		printf("Enter 1 to perform binary search\nEnter 2 to perform bubble sort\nEnter 3 to delete a particular number\nEnter 4 to insert a number in a particular position\nEnter 5 to exit\nEnter your choice ");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1: binary(a, n);
				break;
			case 2:	bub_sort(a, n);
				break;
			case 3: del(a, n);
				break;
			case 4: ins(a, n);n++;
				break;
			case 5: exit(0);
			default: printf("Wrong choice");
		}
	}
	return 0;	
}
