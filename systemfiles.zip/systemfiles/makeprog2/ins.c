#include <stdio.h>
#include <stdlib.h>
void ins(int A[], int n)
{
	int t, i, p;
	printf("\n Enter number to insert:");
	scanf("%d", &t);
	printf("\n Enter position to insert:");
	scanf("%d", &p);
	for (i = n; i >= p; i--)
	{
		A[i] = A[i-1];
	}
	A[i]=t;
	printf("\n List after insertion:\n");
	for (i=0; i<n+1; i++)
		printf("%d\t", A[i]);
printf("\n");
}
