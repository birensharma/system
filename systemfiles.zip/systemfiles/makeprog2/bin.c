#include <stdio.h>
extern void bub_sort();
int binarySearch(int arr[], int l, int r, int x)
{
	if (r >= l)
	{
		int mid = l + (r - l)/2;
		if (arr[mid] == x)
			return mid;
		if (arr[mid] > x)
			return binarySearch(arr, l, mid-1, x);
		return binarySearch(arr, mid+1, r, x);
	}
	return -1;
}
void binary(int A[],int n)
{
	bub_sort(A, n);
	int x ;
	printf("Enter no to find: ");
	scanf("%d",&x);
	int result = binarySearch(A, 0, n-1, x);
	(result == -1) ? printf("Element is not present in array") : printf("Element is present at index %d", result);
	printf("\n");
}
