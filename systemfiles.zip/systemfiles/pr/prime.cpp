#include<stdio.h>
#include<iostream>
using namespace std;

void printPrime(int arr[],int n)
{
	int c,i,j,flag=0;
	bool one=false,two=false;
	for(i=10;i<100;i++)
	{
		for(j=2;j<i/2;j++)
		{
			if(i%j==0)
			{
				flag=0;
				break;
			}
			else
				flag=1;
		}
		if(flag==1)
		{
			for(j=0;j<n;j++)
			{
				if(arr[j]==i/10)
				{
					two=true;
					break;
				}
				else
					two=false;
			}
			for(j=0;j<n;j++)
			{
				if(arr[j]==i%10)
				{
					one=true;
					break;
				}
				else
					one=false;
			}
			if(one && two)
				cout<<"\n"<<i;
		}
	}	
}
int main()
{
	int n,i=0,c=0,temp;
	cout<<"Enter a number-> ";
	cin>>n;
	temp=n;
	while(temp%10!=0)
	{
		c++;
		if(temp/10==0)
			break;
		temp=temp/10;
	}
	int arr[c];
	temp=n;
	while(temp!=0)
	{
		arr[i]=temp%10;
		temp=temp/10;
		i++;
	}
	printPrime(arr,c);
	return 0;
}
