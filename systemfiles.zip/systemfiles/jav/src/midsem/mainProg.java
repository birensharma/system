package midsem;

import java.util.Scanner;
//main program starts
public class mainProg {
	public static void main(String[] args) {
		//scanner class for taking input
		Scanner sc = new Scanner(System.in);
		//Security manager class 
		SecurityManager sec = new SecurityManager();
		//Haunted Manager class
		HauntedHouseMgr h = new HauntedHouseMgr();
		//Merry go round manager class
		MerryGoRoundMgr m = new MerryGoRoundMgr();

		while (true) {
			System.out.println("\n\n-----------------WELCOME----------------Please select one:\n(1)Admin\n" + "(2)Security and entry fee manager\n"
					+ "(3)Haunted house manager" + "\n(4)Merry-go-round manager\n" + "(0)exit\nInput: ");
			//taking input from user to initialize the process
			int inp = sc.nextInt();
			//switch condition for friendly UI
			switch (inp) {
			case 1://admin activities
				if (sec != null && h != null && m != null) {
					admin a = new admin(sec, h, m);
					System.out.println("--------------WELCOME ADMIN------------\nHere is the full report\n");
					float p = a.getProfitorLoss();
					System.out.println("Security and entry manager:\n");
					System.out.println("Name:" + sec.getName());
					System.out.println("Expenses:" + sec.getExpenses());
					System.out.println("Fees Collected:" + sec.getFee());
					System.out.println("\n");

					System.out.println("Haunted House Manager:\n");
					System.out.println("Name:" + h.getName());
					System.out.println("Expenses:" + h.getExpenses());
					System.out.println("Fees Collected:" + h.getFee());
					System.out.println("\n");

					System.out.println("Merry Go Round Manager:\n");
					System.out.println("Name:" + h.getName());
					System.out.println("Expenses:" + h.getExpenses());
					System.out.println("Fees Collected:" + h.getFee());
					System.out.println("\n");

					if (p < 0)
						System.out.println("Loss of :" + p);
					else
						System.out.println("Profit of :" + p);
				} else
					System.out.println("\nNothing to show\n");

				break;
			case 2://Security manager actiivities
				System.out.println("--------------WELCOME SECURITY MANAGER------------\nHere is the full report\n");
				System.out.println("Enter your name:");
				sc.nextLine();
				String name=sc.nextLine();
				sec.setName(name);
				System.out.println("Enter your Expenses:");
				sec.setExpenses();
				System.out.println("Enter Total entry fees collected:");
				sc.nextLine();
				float fee=sc.nextFloat();
				sec.setTotalEntryFees(fee);
				sc.nextLine();
				System.out.println("Enter Security Vulnerability(true or false):");
				boolean stat=sc.nextBoolean();
				
				break;
			case 3://haunted house manager activities
				System.out
						.println("--------------WELCOME HAUNTED HOUSE MANAGER------------\nHere is the full report\n");
				System.out.println("Enter your name:");
				sc.nextLine();
				String name1=sc.nextLine();
				h.setName(name1);
				System.out.println("Enter your Expenses:");
				h.setExpenses();
				System.out.println("Enter Total entry fees collected:");
				sc.nextLine();
				float fee1=sc.nextFloat();
				h.setTotalFees(fee1);

				break;
			case 4://Merry go round manager activities
				System.out
						.println("--------------WELCOME MERRY GO ROUND MANAGER------------\nHere is the full report\n");
				System.out.println("Enter your name:");
				sc.nextLine();
				String name2=sc.nextLine();
				m.setName(name2);
				System.out.println("Enter your Expenses:");
				m.setExpenses();
				System.out.println("Enter Total entry fees collected:");
				sc.nextLine();
				float fee2=sc.nextFloat();
				m.setTotalFees(fee2);
				break;
			case 0://exit the process if input is 0
				System.exit(0);
			default://if input is anything else
				System.out.println("Invalid input\n");
			}
		}
	}
	//end of main program
}
