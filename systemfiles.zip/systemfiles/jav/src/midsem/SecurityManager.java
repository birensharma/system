package midsem;

import java.io.*;
import java.util.Scanner;
//Security manager class 
public class SecurityManager implements wages,expenses {
	File file = new File("SecurityManagerReport.txt");
	FileReader fr;
	FileWriter fw;
	BufferedReader br;
	BufferedWriter bw;
	private String name;
	private float fee,maintainence,tax,phenyl,electricity,water,fuel,wages;
	Scanner sc;
	
	//function for getting name of the manager
	public String getName() {
		return name;
	}
	
	
	//function for setting name of the manager
	public void setName(String name) {
		this.name = name;
		write("Name:"+name+"\n");
	}

	//function for getting wages of the manager
	@Override
	public float getWages() {
		// TODO Auto-generated method stub
		return wages;
	}
	
	//function for writing required text to the file
	private void write(String s) {
		try {
			fw = new FileWriter(file.getAbsolutePath(), true);
			bw = new BufferedWriter(fw);
			bw.append(s);
			bw.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 	
	}
	
	//function for reading from the file
	private void read(){
		try {
			//int i;
			String s;
			fr = new FileReader(file);
			br = new BufferedReader(fr);
			//while ((i = br.read()) != -1)
			while((s=br.readLine())!=null)	
			System.out.print(br.readLine());
			br.close();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}

	//function for setting the total entry fees collected
	public void setTotalEntryFees(float fee) {
		this.fee=fee;
		write("TotalEnterFees:"+fee+"\n");
		System.out.println("Total entry fee set successfully");
	}
	
	//function for getting the total entry fees collected
	public float getFee()
	{
		return fee;
	}
	
	//function for setting security status into the file
	public void setSecurityStatus(boolean status)
	{
		write("Security Vulnerability:"+status+"\n");
	}
	
	//function for setting overall expenses 
	@Override
	public void setExpenses() {
		// TODO Auto-generated method stub
		sc=new Scanner(System.in);
		System.out.println("Maintainence and repairing:");
		maintainence=sc.nextFloat();
		write("Maintainence and repairing:"+maintainence+"\n");
		System.out.println("taxes:");
		tax=sc.nextFloat();
		write("Taxes:"+tax+"\n");
		System.out.println("phenyl:");
		phenyl=sc.nextFloat();
		write("phenyl"+phenyl+"\n");
		System.out.println("electricity:");
		electricity=sc.nextFloat();
		write("Electricity:"+electricity+"\n");
		System.out.println("water:");
		water=sc.nextFloat();
		write("Water:"+water+"\n");
		System.out.println("fuel:");
		fuel=sc.nextFloat();
		write("Fuel:"+fuel+"\n");	
	}

	//function for getting expenses 
	@Override
	public float getExpenses() {
		return maintainence+fuel+water+tax+phenyl+electricity;
	}

	//function for setting wages
	@Override
	public void setWages(float wages) {
		// TODO Auto-generated method stub
		write("Wages:"+wages);
		this.wages=wages;
	}
	

}
