package midsem;
//Admin class
public class admin {
	//required variable initialization
	private float totalExpenses;
	private SecurityManager sec;
	private HauntedHouseMgr h;
	private MerryGoRoundMgr m;
	//constructor for initializing instance variables 
	public admin(SecurityManager sec, HauntedHouseMgr h, MerryGoRoundMgr m) {
		super();
		this.sec = sec;
		this.h = h;
		this.m = m;
	}
	//functioon to get total expenses
	public float getTotalExpenses() {
		totalExpenses= sec.getExpenses() + h.getExpenses() + h.getExpenses();
		return totalExpenses;
	}
	//profit or loss calculation
	public float getProfitorLoss()
	{
		return totalExpenses-(sec.getFee() + h.getFee() + h.getFee());
	}
	

}
