package midsem;
//interface for calculating wages
public interface wages {

	float wage=0f;
	public float getWages();
	public void setWages(float wages);
}
