package midsem;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class MerryGoRoundMgr implements wages,expenses{

	File file = new File("MerryGoRoundManagerReport.txt");
	FileReader fr;
	FileWriter fw;
	BufferedReader br;
	BufferedWriter bw;
	private String name;
	private float fee,maintainence,tax,phenyl,electricity,water,fuel,wages;
	Scanner sc;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
		write("Name:"+name+"\n");
	}

	@Override
	public float getWages() {
		// TODO Auto-generated method stub
		return wages;
	}

	private void write(String s) {
		try {
			fw = new FileWriter(file.getAbsolutePath(), true);
			bw = new BufferedWriter(fw);
			bw.append(s);
			bw.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 	
	}

	private void read(){
		try {
			//int i;
			String s;
			fr = new FileReader(file);
			br = new BufferedReader(fr);
			//while ((i = br.read()) != -1)
			while((s=br.readLine())!=null)	
			System.out.print(br.readLine());
			br.close();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}

	public void setTotalFees(float fee) {
		this.fee=fee;
		write("TotalFeesReceived:"+fee+"\n");
		System.out.println("Total fee set successfully");
	}

	public void setSecurityStatus(boolean status)
	{
		write("Security Vulnerability:"+status+"\n");
	}

	@Override
	public void setExpenses() {
		// TODO Auto-generated method stub
		sc=new Scanner(System.in);
		System.out.println("Maintainence and repairing:");
		maintainence=sc.nextFloat();
		write("Maintainence and repairing:"+maintainence+"\n");
		System.out.println("taxes:");
		tax=sc.nextFloat();
		write("Taxes:"+tax+"\n");
		System.out.println("phenyl:");
		phenyl=sc.nextFloat();
		write("phenyl"+phenyl+"\n");
		System.out.println("electricity:");
		electricity=sc.nextFloat();
		write("Electricity:"+electricity+"\n");
		System.out.println("water:");
		water=sc.nextFloat();
		write("Water:"+water+"\n");
		System.out.println("fuel:");
		fuel=sc.nextFloat();
		write("Fuel:"+fuel+"\n");	
	}

	@Override
	public float getExpenses() {
		return maintainence+fuel+water+tax+phenyl+electricity;
	}

	@Override
	public void setWages(float wages) {
		// TODO Auto-generated method stub
		write("Wages:"+wages);
		this.wages=wages;
	}
	
	public float getFee()
	{
		return fee;
	}


}
