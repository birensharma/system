package midsem;
//interface for calculating expenses
public interface expenses {
 void setExpenses();
 float getExpenses();
}
